Place Bible JSON files here in albible-lite format.
Example: data/uk/lk (JSON array).
