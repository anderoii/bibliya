;(function($){
'use strict';
var S={book:'Mt',ch:1,trans:'r',par:'',totCh:28,sel:[],cfg:{}};

function init(){loadCfg();bind();initProgress();initScrollTop();initUrl();if(BRP.logged)loadBM();}

function initUrl(){
 var urlBook  = (typeof BRP!=='undefined' && BRP.urlBook)    ? BRP.urlBook    : '';
 var urlCh    = (typeof BRP!=='undefined' && BRP.urlChapter) ? BRP.urlChapter : 0;
 var urlVsS   = (typeof BRP!=='undefined' && BRP.urlVerseStart) ? BRP.urlVerseStart : 0;
 var urlVsE   = (typeof BRP!=='undefined' && BRP.urlVerseEnd)   ? BRP.urlVerseEnd   : 0;
 var urlTrans = (typeof BRP!=='undefined' && BRP.urlTrans)   ? BRP.urlTrans   : '';
 var h=location.hash.replace('#','');
 var b='Mt',c=1,t='r',p='';
 if(urlBook){b=urlBook;c=urlCh||1;if(urlTrans)t=urlTrans;}
 else if(h){
  var m=h.match(/^([A-Za-z0-9]+)\.(\d+)(?:[&]([^~]+)(?:~(.+))?)?$/);
  if(m){b=m[1];c=+m[2];if(m[3])t=m[3];if(m[4])p=m[4];}
 } else {
  try{var sv=JSON.parse(localStorage.getItem('brp_pos')||'{}');if(sv.b){b=sv.b;c=sv.c||1;t=sv.t||t;if(sv.p)p=sv.p;}}catch(e){}
 }
 S.book=b;S.ch=c;S.trans=t;S.par=p;S.urlVerseStart=urlVsS;S.urlVerseEnd=urlVsE;
 $('#brp-trans').val(t);if(p)$('#brp-parallel').val(p);updateLang(t);load(b,c,t);
}

function initProgress(){
 $('body').prepend('<div class="brp-progress"><div class="brp-progress-bar" id="brp-prog"></div></div>');
 $(window).on('scroll.brp',function(){
  var st=$(window).scrollTop(),dh=$(document).height()-$(window).height();
  $('#brp-prog').css('width',(dh>0?Math.round(st/dh*100):0)+'%');
 });
}

function initScrollTop(){
 var $btn=$('<button class="brp-scroll-top" title="На початок">↑</button>').appendTo('body');
 $(window).on('scroll.brptop',function(){$btn.toggleClass('on',$(window).scrollTop()>400);});
 $btn.on('click',function(){$('html,body').animate({scrollTop:0},400);});
}

function transLang(code){
 var ru=['r','ru','c','utfcs','cs','b','e','ru-pf','j','f','ru-p','ru-m','ru-d'];
 var en=['a','en-nrsv','en-kjv'];var uk=['k','ua'];
 if(ru.indexOf(code)!==-1)return 'ru';if(en.indexOf(code)!==-1)return 'en';if(uk.indexOf(code)!==-1)return 'uk';return 'en';
}

function updateLang(transCode){
 var lang=transLang(transCode);
 $('.brp-book-link').each(function(){var $el=$(this),nc=$el.find('.brp-nc-mark');var name=$el.data('name-'+lang)||$el.data('name-uk')||$el.data('name-en')||$el.text();$el.text(name);if(nc.length)$el.append(nc);});
 $('.brp-cat-title').each(function(){var $el=$(this);var l=$el.data('cat-'+lang)||$el.data('cat-uk')||$el.text();$el.text(l);});
 $('.brp-tab-btn[data-label-'+lang+']').each(function(){var $el=$(this);var l=$el.data('label-'+lang)||$el.data('label-uk');if(l)$el.text(l);});
 $('.brp-ot-hint,.brp-nc-hint').each(function(){var $el=$(this);var h=$el.data('hint-'+lang)||$el.data('hint-uk');if(h)$el.text(h);});
 $('#brp-search-bf option').each(function(){var $opt=$(this),code=$opt.val();if(!code)return;var $link=$('.brp-book-link[data-code="'+code+'"]');if($link.length){var name=$link.data('name-'+lang)||$link.data('name-uk')||$opt.text();$opt.text(name);}});
}

function bind(){
 $('#brp-mob-btn').on('click',function(){
  var open=!$('#brp-sidebar').hasClass('open');
  $('#brp-sidebar').toggleClass('open');
  if(open)$('<div class="brp-sidebar-overlay on"></div>').appendTo('body');else $('.brp-sidebar-overlay').remove();
 });
 $(document).on('click','.brp-sidebar-overlay',function(){$('#brp-sidebar').removeClass('open');$(this).remove();});
 $(document).on('click',function(e){if($(window).width()<=800&&!$(e.target).closest('#brp-sidebar,#brp-mob-btn').length){$('#brp-sidebar').removeClass('open');$('.brp-sidebar-overlay').remove();}});
 $(document).on('click','.brp-tab-btn',function(){var t=$(this).data('tab');$('.brp-tab-btn').removeClass('active');$(this).addClass('active');$('.brp-tab-pane').removeClass('active');$('#brp-pane-'+t).addClass('active');});
 $(document).on('click','.brp-book-link',function(e){
  e.preventDefault();S.totCh=+$(this).data('ch');load($(this).data('code'),1);
  $('.brp-book-link').removeClass('active');$(this).addClass('active');
  if($(window).width()<=800){$('#brp-sidebar').removeClass('open');$('.brp-sidebar-overlay').remove();}
 });
 $('#brp-trans').on('change',function(){S.trans=this.value;updateLang(S.trans);load(S.book,S.ch);});
 $('#brp-parallel').on('change',function(){S.par=this.value;load(S.book,S.ch);});
 $(document).on('change','#brp-ch-sel',function(){load(S.book,+this.value);});
 $(document).on('click','.brp-ch-n',function(e){e.preventDefault();load(S.book,+$(this).data('n'));});
 $('#brp-prev').on('click',function(){if(S.ch>1)load(S.book,S.ch-1);});
 $('#brp-next').on('click',function(){if(S.ch<S.totCh)load(S.book,S.ch+1);});
 $(document).on('keydown',function(e){
  if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))return;
  if(e.key==='ArrowLeft'||e.key==='PageUp'){e.preventDefault();$('#brp-prev').click();}
  else if(e.key==='ArrowRight'||e.key==='PageDown'){e.preventDefault();$('#brp-next').click();}
  else if(e.key==='Escape')closeModals();
  else if((e.ctrlKey||e.metaKey)&&e.key==='f'){e.preventDefault();modal('brp-search-modal');setTimeout(function(){$('#brp-search-q').focus();},100);}
 });
 var tx=0;
 $(document).on('touchstart',function(e){tx=e.originalEvent.changedTouches[0].clientX;});
 $(document).on('touchend',function(e){
  var dx=e.originalEvent.changedTouches[0].clientX-tx;
  if(Math.abs(dx)>70&&!$(e.target).closest('#brp-sidebar,.brp-modal').length){if(dx>0)$('#brp-prev').click();else $('#brp-next').click();}
 });
 $(document).on('click','.brp-v',function(e){
  /* brp-vn click is handled by popup.js */
  if($(e.target).hasClass('brp-vn')) return;
  $(this).toggleClass('sel');updateSel();showBar();
 });
 $('#brp-copy').on('click',copyVs);$('#brp-bm-btn').on('click',openBmModal);$('#brp-err-btn').on('click',openErrModal);
 $('#brp-set-btn').on('click',function(){modal('brp-set-modal');});
 $('#brp-sb-go').on('click',function(){var q=$('#brp-sb-q').val().trim();if(q.length>=2){modal('brp-search-modal');$('#brp-search-q').val(q);doSearch(1);}});
 $('#brp-sb-q').on('keypress',function(e){if(e.which===13)$('#brp-sb-go').click();});
 $('#brp-search-go').on('click',function(){doSearch(1);});
 $('#brp-search-q').on('keypress',function(e){if(e.which===13)doSearch(1);});
 $(document).on('click','.brp-sr',function(){closeModals();load($(this).data('b'),+$(this).data('c'));});
 $(document).on('click','.brp-page-btn',function(){doSearch(+$(this).data('p'));});
 $(document).on('click','.brp-modal-x',function(){$(this).closest('.brp-modal').removeClass('on');});
 $(document).on('click','.brp-modal',function(e){if($(e.target).hasClass('brp-modal'))closeModals();});
 bindCfg();
 $('#brp-bm-save').on('click',saveBM);
 $(document).on('click','.brp-bm',function(){closeModals();load($(this).data('b'),+$(this).data('c'));});
 $(document).on('click','.brp-bm-del',function(e){e.stopPropagation();delBM(+$(this).data('id'),$(this).closest('.brp-bm'));});
 $('#brp-err-send').on('click',sendErr);
 $(document).on('click','.brp-color-dot',function(){$('.brp-color-dot').removeClass('on');$(this).addClass('on');});
 $(document).on('mousemove',function(e){if(e.clientY>window.innerHeight-90)showBar();});
 $(window).on('scroll',function(){showBar();});
}

function load(bk,ch,tr){
 tr=tr||S.trans;S.book=bk;S.ch=ch;S.trans=tr;S.sel=[];
 $('#brp-loader').addClass('on');
 $.post(BRP.ajax,{action:'brp_load_chapter',nonce:BRP.nonce,book:bk,chapter:ch,trans:tr,parallel:S.par},function(r){
  $('#brp-loader').removeClass('on');if(!r.success){toast('Помилка завантаження');return;}
  renderVs(r.data);updateNav(r.data);updateUrl(bk,ch,tr);savePos(bk,ch,tr);
  if(!S.urlVerseStart)window.scrollTo({top:0,behavior:'smooth'});
 }).fail(function(){$('#brp-loader').removeClass('on');toast("Помилка з'єднання");});
}

function renderVs(d){
 var c=$('#brp-content').empty().removeClass('loaded');
 if(!d.verses||!d.verses.length){c.html('<p class="brp-empty">Текст відсутній. Імпортуйте через адмін-панель.</p>');return;}
 var vsS=S.urlVerseStart||0,vsE=S.urlVerseEnd||0;S.urlVerseStart=0;S.urlVerseEnd=0;
 var hasPar=d.parallel&&d.parallel.length>0;
 var mainDir=transDir(S.trans),parDir=transDir(S.par);
 var mainLang=transLangCode(S.trans),parLang=transLangCode(S.par);
 $('#brp').attr('data-brp-dir',mainDir).attr('data-brp-trans',S.trans).attr('data-brp-color-cols',S.cfg.colorCols?'true':'false');
 if(hasPar){
  var mN=$('#brp-trans option:selected').text(),pN=$('#brp-parallel option:selected').text();
  var h='<div class="brp-parallel"><div class="brp-pcol" data-lang="'+mainLang+'" data-dir="'+mainDir+'"><div class="brp-pcol-head">'+esc(mN)+'</div>';
  d.verses.forEach(function(v){h+=vHtml(v,'',vsS,vsE);});
  h+='</div><div class="brp-pcol'+(parLang==='cu'?' brp-pcol-cs':'')+(parDir==='rtl'?' brp-pcol-rtl':'')+'\" data-lang="'+parLang+'" data-dir="'+parDir+'"><div class="brp-pcol-head">'+esc(pN)+'</div>';
  d.parallel.forEach(function(v){h+=vHtml(v,'p',vsS,vsE);});
  h+='</div></div>';c.html(h);
 } else {var h='';d.verses.forEach(function(v){h+=vHtml(v,'',vsS,vsE);});c.html(h);}
 setTimeout(function(){c.addClass('loaded');},50);
 if(vsS>0){setTimeout(function(){var $t=$('#v'+vsS);if($t.length)$('html,body').animate({scrollTop:$t.offset().top-100},300);},250);}
}

function transDir(code){return ['i','he','ar','n','syc'].indexOf(code)!==-1?'rtl':'ltr';}
function transLangCode(code){var m={'c':'cu','utfcs':'cu','cs':'cu','r':'ru','ru':'ru','b':'ru','e':'ru','k':'uk','ua':'uk','a':'en','en-nrsv':'en','en-kjv':'en','g':'el','el':'el','i':'he','he':'he','l':'la','de_ml':'de','m':'de','h':'fr','w':'es','ar':'ar','n':'ar','chn':'zh','jp':'ja','pl':'pl','bg':'bg','it':'it','pt':'pt','sb':'sr','z':'sr','ro':'ro'};return m[code]||'other';}

function vHtml(v,pfx,vsS,vsE){
 pfx=pfx||'';var vn=+v.verse;var cw=+v.is_christ_words?' brp-cw':'';
 var inR=(vsS>0&&vsE>0&&vn>=vsS&&vn<=vsE);
 return '<p class="brp-v'+(inR?' brp-v-highlighted':'')+'\" data-v="'+vn+'" id="'+pfx+'v'+vn+'">'+
  '<span class="brp-v-check"></span>'+
  '<sup class="brp-vn">'+vn+'</sup> '+
  (inR?'<strong class="brp-in-range">':'')+
  '<span class="brp-vt'+cw+'">'+v.verse_text+'</span>'+
  (inR?'</strong>':'')+
  '</p>';
}

function updateNav(d){
 var lang=transLang(S.trans);
 var bn=d.book?(d.book['name_'+lang]||d.book.name_uk||d.book.name_ru||d.book.name_en):S.book;
 S.totCh=d.total||S.totCh;$('#brp-book-name').text(bn);
 var sel=$('#brp-ch-sel').empty();for(var i=1;i<=S.totCh;i++)sel.append('<option value="'+i+'"'+(i===d.chapter?' selected':'')+'>'+i+'</option>');
 var g=$('#brp-ch-grid').empty();for(var i=1;i<=S.totCh;i++)g.append('<button class="brp-ch-n'+(i===d.chapter?' active':'')+'\" data-n="'+i+'">'+i+'</button>');
 $('.brp-book-link').removeClass('active');$('.brp-book-link[data-code="'+S.book+'"]').addClass('active');
 var $ab=$('.brp-book-link.active');if($ab.length){var sb=$('#brp-sidebar')[0];if(sb){sb.scrollTop=$ab.offset().top-$('#brp-sidebar').offset().top+sb.scrollTop-80;}}
}

function updateUrl(b,c,t){var h=b+'.'+c+'&'+t;if(S.par)h+='~'+S.par;if(history.replaceState)history.replaceState(null,'','#'+h);else location.hash=h;}
function savePos(b,c,t){localStorage.setItem('brp_pos',JSON.stringify({b:b,c:c,t:t,p:S.par}));}

function updateSel(){S.sel=[];$('.brp-v.sel').each(function(){S.sel.push(+$(this).data('v'));});S.sel.sort(function(a,b){return a-b;});}
function showBar(){var bar=$('#brp-bottom').removeClass('hidden');var d=+S.cfg.barDelay;if(d>0){clearTimeout(S._bt);S._bt=setTimeout(function(){bar.addClass('hidden');},d);}}

function copyVs(){
 var txt='',bn=$('#brp-book-name').text(),ch=S.ch;
 if(S.sel.length){
  S.sel.forEach(function(v){var el=$('.brp-v[data-v="'+v+'"]').first().find('.brp-vt').text();txt+=(S.cfg.copyVn?v+' ':'')+el+(S.cfg.copyBr?'\n':' ');});
  var ref=S.sel.length===1?':'+S.sel[0]:':'+S.sel[0]+'-'+S.sel[S.sel.length-1];
  txt=(S.cfg.copyQ?'«':'')+txt.trim()+(S.cfg.copyQ?'»':'')+'\n('+bn+' '+ch+ref+')';
 } else {var s=window.getSelection();if(s&&s.toString().trim())txt=s.toString();else{toast('Оберіть вірші для копіювання');return;}}
 navigator.clipboard.writeText(txt.trim()).then(function(){toast('✓ Скопійовано!');}).catch(function(){var ta=document.createElement('textarea');ta.value=txt.trim();document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);toast('✓ Скопійовано!');});
}

function doSearch(pg){
 var q=$('#brp-search-q').val().trim(),bf=$('#brp-search-bf').val(),res=$('#brp-search-res');
 if(q.length<2){toast('Мінімум 2 символи');return;}
 res.html('<p class="brp-empty">Пошук…</p>');
 $.post(BRP.ajax,{action:'brp_search',nonce:BRP.nonce,q:q,trans:S.trans,book_filter:bf,page:pg},function(r){
  if(!r.success){res.html('<p class="brp-empty">Сталася помилка</p>');return;}
  var d=r.data;res.empty();
  if(!d.results||!d.results.length){res.html('<p class="brp-empty">Нічого не знайдено</p>');return;}
  res.append('<p class="brp-sr-info">Знайдено: '+d.total+' (стор. '+d.page+'/'+d.pages+')</p>');
  d.results.forEach(function(r){var hl=esc(r.verse_text).replace(new RegExp('('+q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','gi'),'<mark>$1</mark>');res.append('<div class="brp-sr" data-b="'+r.book_code+'" data-c="'+r.chapter+'"><div class="brp-sr-ref">'+esc(r.name_uk||r.name_ru||r.book_code)+' '+r.chapter+':'+r.verse+'</div><div class="brp-sr-text">'+hl+'</div></div>');});
  if(d.pages>1){var pp='<div class="brp-sr-pages">';for(var i=1;i<=Math.min(d.pages,10);i++)pp+='<button class="brp-btn brp-btn-sm brp-page-btn'+(i===d.page?' brp-btn-primary':'')+'\" data-p="'+i+'">'+i+'</button>';pp+='</div>';res.append(pp);}
 });
}

function loadComm(verse){
 var bn=$('#brp-book-name').text();
 var verseText=$('.brp-v[data-v="'+verse+'"]').first().find('.brp-vt').text().trim();
 var ref=bn+' '+S.ch+':'+verse;
 /* Show verse reference + loading state */
 var box=$('#brp-comm-list');
 box.html('<div class="brp-comm-ref">'+esc(ref)+'</div>'
  +(verseText?'<div class="brp-comm-verse">'+esc(verseText)+'</div>':'')
  +'<div class="brp-ai-loading"><div class="brp-ai-dots"><span></span><span></span><span></span></div><span>Завантаження тлумачень…</span></div>');
 /* First try DB commentaries */
 $.post(BRP.ajax,{action:'brp_get_commentary',nonce:BRP.nonce,book:S.book,chapter:S.ch,verse:verse},function(r){
  var dbCards='';
  if(r.success&&r.data.commentaries&&r.data.commentaries.length){
   r.data.commentaries.forEach(function(c){
    dbCards+='<div class="brp-commentary-card"><div class="brp-commentary-author">'+esc(c.author)+'</div><div class="brp-commentary-text">'+c.body+'</div></div>';
   });
  }
  /* Then call Anthropic API for AI commentary */
  brpLoadAIComm(ref,verseText,dbCards,box);
 }).fail(function(){
  brpLoadAIComm(ref,verseText,'',box);
 });
}

function brpLoadAIComm(ref,verseText,dbCards,box){
 if(!verseText){
  box.find('.brp-ai-loading').replaceWith(dbCards||'<p class="brp-empty">Тлумачень не знайдено</p>');
  return;
 }
 var prompt='Ти православний богослов і тлумач Святого Письма. Надай тлумачення наступного біблійного вірша українською мовою.\n\nВірш: '+ref+'\nТекст: "'+verseText+'"\n\nВідповідай СТРОГО у форматі JSON (без markdown, без пояснень до і після):\n{"patristic_author":"ім\'я святого отця (Іоанн Золотоустий, Феофілакт Болгарський, Блаженний Августин тощо)","patristic":"тлумачення від святих отців 2-3 речення","theological":"богословський аналіз 2-3 речення","application":"практичне духовне застосування 1-2 речення"}';
 fetch('https://api.anthropic.com/v1/messages',{
  method:'POST',
  headers:{'Content-Type':'application/json'},
  body:JSON.stringify({model:'claude-sonnet-4-20250514',max_tokens:1000,messages:[{role:'user',content:prompt}]})
 }).then(function(res){return res.json();}).then(function(data){
  var raw=(data.content&&data.content[0])?data.content[0].text:'';
  var ai;
  try{ai=JSON.parse(raw.replace(/```json|```/g,'').trim());}catch(e){ai=null;}
  var aiCards='';
  if(ai){
   if(ai.patristic) aiCards+='<div class="brp-commentary-card"><div class="brp-commentary-author">'+esc(ai.patristic_author||'Святоотецьке тлумачення')+'</div><div class="brp-commentary-text">'+esc(ai.patristic)+'</div></div>';
   if(ai.theological) aiCards+='<div class="brp-commentary-card"><div class="brp-commentary-author">Богословський аналіз</div><div class="brp-commentary-text">'+esc(ai.theological)+'</div></div>';
   if(ai.application) aiCards+='<div class="brp-commentary-card"><div class="brp-commentary-author">Духовне застосування</div><div class="brp-commentary-text">'+esc(ai.application)+'</div></div>';
  }
  var allCards=dbCards+aiCards;
  box.find('.brp-ai-loading').replaceWith(allCards||'<p class="brp-empty">Тлумачень не знайдено</p>');
 }).catch(function(){
  box.find('.brp-ai-loading').replaceWith(dbCards||'<p class="brp-empty">Не вдалося завантажити тлумачення</p>');
 });
}

function openBmModal(){if(!BRP.logged){toast('Увійдіть для збереження закладок');return;}var bn=$('#brp-book-name').text(),ref=bn+' '+S.ch;if(S.sel.length){ref+=':'+S.sel[0];if(S.sel.length>1)ref+='-'+S.sel[S.sel.length-1];}$('#brp-bm-ref').text(ref);modal('brp-bm-modal');}
function saveBM(){var c=$('.brp-color-dot.on').data('c')||'#C9A96E',note=$('#brp-bm-note').val();$.post(BRP.ajax,{action:'brp_save_bookmark',nonce:BRP.nonce,book_code:S.book,chapter:S.ch,vs:S.sel[0]||0,ve:S.sel[S.sel.length-1]||0,color:c,note:note},function(r){if(r.success){toast('★ Закладку збережено!');closeModals();$('#brp-bm-note').val('');loadBM();}});}
function loadBM(){$.post(BRP.ajax,{action:'brp_get_bookmarks',nonce:BRP.nonce},function(r){if(!r.success)return;var list=$('#brp-bm-list').empty();if(!r.data.bookmarks||!r.data.bookmarks.length){list.html('<p class="brp-empty">Закладок поки немає</p>');return;}r.data.bookmarks.forEach(function(b){var ref=(b.name_uk||b.book_code)+' '+b.chapter;if(b.verse_start){ref+=':'+b.verse_start;if(b.verse_end&&b.verse_end!=b.verse_start)ref+='-'+b.verse_end;}list.append('<div class="brp-bm" data-b="'+b.book_code+'" data-c="'+b.chapter+'" style="border-left-color:'+b.color+'"><button class="brp-bm-del" data-id="'+b.id+'">✕</button><div class="brp-bm-ref">'+esc(ref)+'</div>'+(b.note?'<div class="brp-bm-note">'+esc(b.note)+'</div>':'')+' </div>');});});}
function delBM(id,el){$.post(BRP.ajax,{action:'brp_del_bookmark',nonce:BRP.nonce,id:id},function(r){if(r.success)el.fadeOut(200,function(){$(this).remove();});});}

function openErrModal(){var s=window.getSelection(),txt=s?s.toString().trim():'';$('#brp-err-sel').text(txt||'(нічого)');modal('brp-err-modal');}
function sendErr(){$.post(BRP.ajax,{action:'brp_report_error',nonce:BRP.nonce,book_code:S.book,chapter:S.ch,trans:S.trans,sel_text:$('#brp-err-sel').text(),desc:$('#brp-err-desc').val()},function(r){if(r.success){toast('Дякуємо! Помилку надіслано.');closeModals();$('#brp-err-desc').val('');}});}

function loadCfg(){
 var def={font:"'Lora','Palatino Linotype',Georgia,serif",size:19,fs:'md',bold:false,justify:true,hyphens:false,theme:'default',christColor:'red',width:'medium',hideVn:false,copyVn:true,copyBr:false,copyQ:false,barDelay:2000,savePos:true,colorCols:false,speechItalic:false};
 try{var sv=JSON.parse(localStorage.getItem('brp_cfg')||'{}');S.cfg=$.extend({},def,sv);}catch(e){S.cfg=def;}
 applyCfg();
}
function applyCfg(){
 var a=$('#brp'),c=S.cfg;
 /* font-size via data-brp-fs attribute for the CSS variable system */
 var fsMap={sm:'sm',md:'md',lg:'lg',xl:'xl'};
 a.attr('data-brp-fs',fsMap[c.fs||'md']||'md');
 a.css('font-family',c.font);
 a.attr('data-brp-theme',c.theme).attr('data-brp-width',c.width).attr('data-brp-christ',c.christColor).attr('data-brp-bold',c.bold).attr('data-brp-justify',c.justify).attr('data-brp-hide-vn',c.hideVn);
 if(c.hyphens)a.css({'-webkit-hyphens':'auto','hyphens':'auto'});else a.css({'-webkit-hyphens':'manual','hyphens':'manual'});
 if(c.speechItalic)a.attr('data-brp-speech-italic','true');else a.removeAttr('data-brp-speech-italic');
 /* theme=default => remove bg so WordPress theme shows through */
 if(c.theme==='default'){a.css('background','transparent');}else{a.css('background','');}
 $('#brp-s-font').val(c.font);
 $('#brp-s-bold').prop('checked',c.bold);$('#brp-s-justify').prop('checked',c.justify);$('#brp-s-hyphens').prop('checked',c.hyphens);
 $('input[name=brp_cw][value='+c.christColor+']').prop('checked',true);
 $('#brp-s-hide-vn').prop('checked',c.hideVn);$('#brp-s-copy-vn').prop('checked',c.copyVn);$('#brp-s-copy-br').prop('checked',c.copyBr);$('#brp-s-copy-q').prop('checked',c.copyQ);$('#brp-s-color-cols').prop('checked',c.colorCols);$('#brp-s-speech-italic').prop('checked',c.speechItalic);
 $('.brp-theme-btn').removeClass('on');$('.brp-theme-btn[data-t='+c.theme+']').addClass('on');
 $('.brp-width-btn').removeClass('on');$('.brp-width-btn[data-w='+c.width+']').addClass('on');
 $('.brp-fs-btn').removeClass('on');$('.brp-fs-btn[data-fs='+(c.fs||'md')+']').addClass('on');
}
function saveCfg(){localStorage.setItem('brp_cfg',JSON.stringify(S.cfg));}
function setCfg(k,v){S.cfg[k]=v;saveCfg();applyCfg();}
function bindCfg(){
 $('#brp-s-font').on('change',function(){setCfg('font',this.value);});
 $('#brp-s-size').on('input',function(){setCfg('size',+this.value);});
 $('#brp-s-bold').on('change',function(){setCfg('bold',this.checked);});
 $('#brp-s-justify').on('change',function(){setCfg('justify',this.checked);});
 $('#brp-s-hyphens').on('change',function(){setCfg('hyphens',this.checked);});
 $(document).on('click','.brp-theme-btn',function(){setCfg('theme',$(this).data('t'));});
 $(document).on('click','.brp-fs-btn',function(){setCfg('fs',$(this).data('fs'));});
 $('input[name=brp_cw]').on('change',function(){setCfg('christColor',this.value);});
 $(document).on('click','.brp-width-btn',function(){setCfg('width',$(this).data('w'));});
 $('#brp-s-hide-vn').on('change',function(){setCfg('hideVn',this.checked);});
 $('#brp-s-copy-vn').on('change',function(){S.cfg.copyVn=this.checked;saveCfg();});
 $('#brp-s-copy-br').on('change',function(){S.cfg.copyBr=this.checked;saveCfg();});
 $('#brp-s-copy-q').on('change',function(){S.cfg.copyQ=this.checked;saveCfg();});
 $('#brp-s-bar-delay').on('change',function(){S.cfg.barDelay=+this.value;saveCfg();});
 $('#brp-s-save-pos').on('change',function(){S.cfg.savePos=this.checked;saveCfg();});
 $('#brp-s-color-cols').on('change',function(){S.cfg.colorCols=this.checked;saveCfg();$('#brp').attr('data-brp-color-cols',this.checked?'true':'false');});
 $('#brp-s-speech-italic').on('change',function(){setCfg('speechItalic',this.checked);});
 $('#brp-s-reset').on('click',function(){if(confirm('Скинути всі налаштування?')){localStorage.removeItem('brp_cfg');location.reload();}});
}

function modal(id){$('#'+id).addClass('on');}
function closeModals(){$('.brp-modal').removeClass('on');}
function toast(msg){var t=$('#brp-toast').text(msg).addClass('on');clearTimeout(toast._t);toast._t=setTimeout(function(){t.removeClass('on');},2800);}
function esc(s){if(!s)return '';return $('<div>').text(s).html();}

$(document).ready(init);
})(jQuery);
