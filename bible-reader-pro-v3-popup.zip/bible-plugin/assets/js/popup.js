/* ═══════════════════════════════════════════════════════════════
   VERSE POPUP — Перехресні посилання + Тлумачення
   Активується кліком на .brp-vn (номер вірша)
═══════════════════════════════════════════════════════════════ */
;(function($){
'use strict';

/* ── Глобальний стан попапу ── */
var Pop = {
    $el: null,
    book: '', ch: 0, verse: 0,
    verseText: '',
    activeTab: 'xref',
    xrefLoaded: false,
    commLoaded: false,
};

/* ── Ініціалізація ── */
function initPopup(){
    // Відкрити при кліці на номер вірша
    $(document).on('click.brp-popup', '.brp-vn', function(e){
        e.preventDefault();
        e.stopPropagation();
        var $vn   = $(this);
        var $verse = $vn.closest('.brp-v');
        var vNum  = parseInt($verse.data('v'), 10);
        var vText = $verse.find('.brp-vt').text().trim();
        openPopup($vn, vNum, vText);
    });

    // Закрити кліком поза попапом
    $(document).on('click.brp-popup-close', function(e){
        if(Pop.$el && !$(e.target).closest('.brp-verse-popup').length && !$(e.target).hasClass('brp-vn')){
            closePopup();
        }
    });

    // Закрити Escape
    $(document).on('keydown.brp-popup', function(e){
        if(e.key === 'Escape') closePopup();
    });
}

/* ── Відкрити попап ── */
function openPopup($anchor, vNum, vText){
    // Оновити стан
    Pop.book = (typeof S !== 'undefined') ? S.book : '';
    Pop.ch   = (typeof S !== 'undefined') ? S.ch   : 0;
    Pop.verse = vNum;
    Pop.verseText = vText;
    Pop.xrefLoaded = false;
    Pop.commLoaded = false;
    Pop.activeTab  = 'xref';

    // Підсвітити вірш
    $('.brp-v').removeClass('brp-v-active');
    $anchor.closest('.brp-v').addClass('brp-v-active');

    // Синхронізувати правий бокову панель
    updateRightPanel(vNum, vText);

    // Видалити попередній
    $('.brp-verse-popup').remove();

    // Отримати ref
    var bookName = $('#brp-book-name').text() || Pop.book;
    var ref      = bookName + ' ' + Pop.ch + ':' + vNum;

    // Побудувати HTML
    var html = buildPopupHTML(ref, vText);
    Pop.$el  = $(html).appendTo('#brp');

    // Позиціонувати
    positionPopup($anchor);

    // Завантажити перехресні посилання одразу
    loadXrefs();
}

/* ── Побудова HTML попапу ── */
function buildPopupHTML(ref, vText){
    var shortText = vText.length > 120 ? vText.slice(0,120)+'…' : vText;
    return [
        '<div class="brp-verse-popup" role="dialog" aria-modal="true">',
          '<div class="brp-popup-head">',
            '<span class="brp-popup-ref">'+ escHtml(ref) +'</span>',
            '<button class="brp-popup-close" title="Закрити (Esc)">✕</button>',
          '</div>',
          (vText ? '<div class="brp-popup-verse">'+ escHtml(shortText) +'</div>' : ''),
          '<div class="brp-popup-actions">',
            '<button class="brp-popup-btn active" data-tab="xref">',
              '<span class="icon">🔗</span>Посилання',
            '</button>',
            '<button class="brp-popup-btn" data-tab="comm">',
              '<span class="icon">📖</span>Тлумачення',
            '</button>',
            '<button class="brp-popup-btn brp-pp-copy" data-tab="">',
              '<span class="icon">📋</span>Копіювати',
            '</button>',
            '<button class="brp-popup-btn brp-pp-bm" data-tab="">',
              '<span class="icon">★</span>Закладка',
            '</button>',
          '</div>',
          '<div class="brp-popup-tabs">',
            '<div class="brp-popup-tab active" data-tab-pane="xref">',
              '<div class="brp-xref-loading">',
                '<div class="brp-ai-dots"><span></span><span></span><span></span></div>',
                '<span>Шукаємо паралельні місця…</span>',
              '</div>',
            '</div>',
            '<div class="brp-popup-tab" data-tab-pane="comm">',
              '<div class="brp-xref-loading">',
                '<div class="brp-ai-dots"><span></span><span></span><span></span></div>',
                '<span>Завантаження тлумачення…</span>',
              '</div>',
            '</div>',
          '</div>',
          '<div class="brp-popup-footer">',
            '<button class="brp-popup-footer-link brp-pp-show-all">Усі тлумачення в панелі</button>',
          '</div>',
        '</div>'
    ].join('');
}

/* ── Позиціонування ── */
function positionPopup($anchor){
    if(!Pop.$el) return;
    var offset   = $anchor.offset();
    var vH       = Pop.$el.outerHeight(true) || 360;
    var winH     = $(window).height();
    var scrollY  = $(window).scrollTop();
    var popW     = 340;
    var anchorH  = $anchor.outerHeight();
    var left     = offset.left;
    var top      = offset.top + anchorH + 6;

    // Вмістити по ширині
    var winW = $(window).width();
    if(left + popW > winW - 10) left = winW - popW - 10;
    if(left < 10) left = 10;

    // Перевірити чи вписується знизу
    var above = (top + vH > scrollY + winH - 20);
    Pop.$el.css({ position:'absolute', left: left, top: above ? (offset.top - vH - 6) : top });
    if(above) Pop.$el.addClass('brp-popup-above');
}

/* ── Tabs ── */
$(document).on('click.brp-popup', '.brp-popup-btn[data-tab]', function(){
    var tab = $(this).data('tab');
    if(!tab) return; // copy/bm handled separately

    Pop.activeTab = tab;
    $('.brp-popup-btn').removeClass('active');
    $(this).addClass('active');
    $('.brp-popup-tab').removeClass('active');
    $('[data-tab-pane="'+tab+'"]').addClass('active');

    if(tab === 'comm' && !Pop.commLoaded) loadCommPopup();
});

/* ── Copy ── */
$(document).on('click.brp-popup', '.brp-pp-copy', function(){
    var bookName = $('#brp-book-name').text();
    var ref = '(' + bookName + ' ' + Pop.ch + ':' + Pop.verse + ')';
    var txt = Pop.verseText + '\n' + ref;
    navigator.clipboard.writeText(txt).then(function(){
        brpToast('✓ Вірш скопійовано!');
    }).catch(function(){
        var ta = document.createElement('textarea');
        ta.value = txt;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        brpToast('✓ Скопійовано!');
    });
});

/* ── Bookmark ── */
$(document).on('click.brp-popup', '.brp-pp-bm', function(){
    closePopup();
    if(typeof openBmModal === 'function'){
        if(typeof S !== 'undefined'){ S.sel = [Pop.verse]; }
        openBmModal();
    }
});

/* ── Show all in right panel ── */
$(document).on('click.brp-popup', '.brp-pp-show-all', function(){
    closePopup();
    // Trigger full commentary load in right panel
    if(typeof loadComm === 'function') loadComm(Pop.verse);
});

/* ── Close ── */
$(document).on('click.brp-popup', '.brp-popup-close', function(){
    closePopup();
});

function closePopup(){
    if(Pop.$el){ Pop.$el.css({opacity:0,transform:'translateY(-4px)'}).delay(150).queue(function(){ $(this).remove().dequeue(); Pop.$el=null; }); }
    $('.brp-v').removeClass('brp-v-active');
}

/* ── Клік по xref-item → перейти до цього вірша ── */
$(document).on('click.brp-popup', '.brp-xref-item', function(){
    var bk = $(this).data('bk');
    var ch = +$(this).data('ch');
    var vs = +$(this).data('vs');
    if(bk && ch){
        closePopup();
        if(typeof load === 'function'){
            load(bk, ch);
            // підсвітити вірш після завантаження
            if(vs){ setTimeout(function(){ highlightVerse(vs); }, 600); }
        }
    }
});

function highlightVerse(vNum){
    var $v = $('.brp-v[data-v="'+vNum+'"]');
    if($v.length){
        $('html,body').animate({ scrollTop: $v.offset().top - 120 }, 300);
        $v.addClass('brp-v-highlighted');
        setTimeout(function(){ $v.removeClass('brp-v-highlighted'); }, 2500);
    }
}

/* ═══ LOAD CROSS-REFERENCES via Anthropic API ═══ */
function loadXrefs(){
    var pane = Pop.$el.find('[data-tab-pane="xref"]');
    var ref  = $('#brp-book-name').text() + ' ' + Pop.ch + ':' + Pop.verse;
    var vText = Pop.verseText;

    // First try DB cross-refs if table exists
    $.post(BRP.ajax, {
        action:'brp_get_commentary',
        nonce:BRP.nonce,
        book:Pop.book, chapter:Pop.ch, verse:Pop.verse
    }, function(r){
        // regardless of DB result, also call AI for xrefs
        brpAIXrefs(ref, vText, pane, r.success ? r.data.commentaries : []);
    }).fail(function(){
        brpAIXrefs(ref, vText, pane, []);
    });
}

function brpAIXrefs(ref, vText, pane, dbComm){
    if(!vText){ pane.html('<p class="brp-empty">Текст вірша не знайдено</p>'); return; }

    var prompt = 'Ти православний богослов і бібліст. Знайди 6-10 паралельних місць у Біблії (перехресні посилання) для наступного вірша.\n\n'+
        'Вірш: '+ref+'\nТекст: "'+vText+'"\n\n'+
        'Відповідай СТРОГО у форматі JSON масиву (без markdown, без пояснень):\n'+
        '[{"ref":"Бут 1:1","book_code":"Gn","chapter":1,"verse":1,"text":"короткий текст вірша"},...]';

    fetch('https://api.anthropic.com/v1/messages',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
            model:'claude-sonnet-4-20250514',
            max_tokens:1200,
            messages:[{role:'user',content:prompt}]
        })
    }).then(function(r){ return r.json(); }).then(function(data){
        var raw = (data.content&&data.content[0]) ? data.content[0].text : '';
        var xrefs;
        try{ xrefs = JSON.parse(raw.replace(/```json|```/g,'').trim()); }catch(e){ xrefs = []; }

        Pop.xrefLoaded = true;
        renderXrefs(pane, xrefs, dbComm);
    }).catch(function(){
        pane.html('<p class="brp-empty">Не вдалось завантажити посилання</p>');
    });
}

function renderXrefs(pane, xrefs, dbComm){
    if(!xrefs || !xrefs.length){
        pane.html('<p class="brp-empty">Паралельних місць не знайдено</p>');
        return;
    }
    var html = '<div class="brp-popup-xrefs">';
    xrefs.forEach(function(x){
        html += '<div class="brp-xref-item" data-bk="'+escAttr(x.book_code)+'" data-ch="'+x.chapter+'" data-vs="'+x.verse+'">';
        html += '<span class="brp-xref-ref">'+escHtml(x.ref)+'</span>';
        html += '<span class="brp-xref-text">'+escHtml(x.text||'')+'</span>';
        html += '</div>';
    });
    html += '</div>';
    pane.html(html);
}

/* ═══ COMMENTARY в попапі ═══ */
function loadCommPopup(){
    var pane  = Pop.$el.find('[data-tab-pane="comm"]');
    var ref   = $('#brp-book-name').text() + ' ' + Pop.ch + ':' + Pop.verse;
    var vText = Pop.verseText;

    if(!vText){ pane.html('<p class="brp-empty">Текст вірша не знайдено</p>'); return; }

    var prompt = 'Ти православний богослов. Надай коротке тлумачення вірша "'+ref+'" текст: "'+vText+'"\n\n'+
        'СТРОГО JSON (без markdown):\n'+
        '{"author":"ім\'я отця","text":"коротке тлумачення до 4 речень"}';

    fetch('https://api.anthropic.com/v1/messages',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
            model:'claude-sonnet-4-20250514',
            max_tokens:600,
            messages:[{role:'user',content:prompt}]
        })
    }).then(function(r){ return r.json(); }).then(function(data){
        var raw = (data.content&&data.content[0]) ? data.content[0].text : '';
        var c;
        try{ c = JSON.parse(raw.replace(/```json|```/g,'').trim()); }catch(e){ c=null; }
        Pop.commLoaded = true;
        if(c && c.text){
            pane.html(
                '<div class="brp-popup-comm"><div class="brp-popup-comm-card">'+
                '<div class="brp-popup-comm-author">'+escHtml(c.author||'Тлумачення')+'</div>'+
                '<div class="brp-popup-comm-text">'+escHtml(c.text)+'</div>'+
                '</div></div>'
            );
        } else {
            pane.html('<p class="brp-empty">Тлумачення не знайдено</p>');
        }
    }).catch(function(){
        pane.html('<p class="brp-empty">Помилка завантаження</p>');
    });
}

/* ═══ RIGHT PANEL sync ═══ */
function updateRightPanel(vNum, vText){
    var bookName = $('#brp-book-name').text();
    var ref      = bookName + ' ' + Pop.ch + ':' + vNum;
    var box      = $('#brp-comm-list');

    box.html(
        '<div class="brp-comm-ref">'+escHtml(ref)+'</div>'+
        (vText ? '<div class="brp-comm-verse">'+escHtml(vText)+'</div>' : '')+
        '<div class="brp-ai-loading"><div class="brp-ai-dots"><span></span><span></span><span></span></div><span>Завантаження…</span></div>'
    );

    // Full commentary in right panel
    $.post(BRP.ajax,{action:'brp_get_commentary',nonce:BRP.nonce,book:Pop.book,chapter:Pop.ch,verse:vNum},function(r){
        var dbCards='';
        if(r.success&&r.data.commentaries&&r.data.commentaries.length){
            r.data.commentaries.forEach(function(c){
                dbCards+='<div class="brp-commentary-card"><div class="brp-commentary-author">'+escHtml(c.author)+'</div><div class="brp-commentary-text">'+c.body+'</div></div>';
            });
        }
        brpLoadAIComm(ref, vText, dbCards, box);
    }).fail(function(){
        brpLoadAIComm(ref, vText, '', box);
    });
}

/* ── helpers ── */
function escHtml(s){ return $('<div>').text(s||'').html(); }
function escAttr(s){ return String(s||'').replace(/"/g,'&quot;'); }
function brpToast(msg){ if(typeof toast==='function') toast(msg); }

/* ── INIT ── */
$(document).ready(function(){
    initPopup();
});

})(jQuery);
