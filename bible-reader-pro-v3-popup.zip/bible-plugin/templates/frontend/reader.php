<?php if(!defined('ABSPATH'))exit;
$nt=array_filter($books,fn($b)=>$b->testament==='NT');
$ot=array_filter($books,fn($b)=>$b->testament==='OT');
$cats_nt=['gospels'=>'Євангелія','acts'=>'Діяння Апостолів','catholic'=>'Соборні Послання','paul'=>'Послання ап. Павла','prophecy_nt'=>'Одкровення'];
$cats_ot=['pentateuch'=>"П'ятикнижжя",'historical'=>'Історичні','historical_nc'=>'Історичні (некан.)','wisdom'=>'Повчальні','wisdom_nc'=>'Повчальні (некан.)','prophets'=>'Великі пророки','prophets_minor'=>'Малі пророки','prophets_nc'=>'Пророчі (некан.)'];

$init_book        = esc_js($url_book ?? '');
$init_chapter     = (int)($url_ch_data['chapter']     ?? 0);
$init_verse_start = (int)($url_ch_data['verse_start'] ?? 0);
$init_verse_end   = (int)($url_ch_data['verse_end']   ?? 0);
$init_trans       = esc_js($url_trans ?? '');
?>
<script>
if(typeof BRP!=='undefined'){
    BRP.urlBook        = '<?= $init_book ?>';
    BRP.urlChapter     = <?= $init_chapter ?: 'null' ?>;
    BRP.urlVerseStart  = <?= $init_verse_start ?: 'null' ?>;
    BRP.urlVerseEnd    = <?= $init_verse_end ?: 'null' ?>;
    BRP.urlTrans       = '<?= $init_trans ?>';
}
</script>
<div id="brp" data-brp-theme="<?php echo esc_attr($default_theme??'default'); ?>" data-brp-width="medium" data-brp-christ="red" data-brp-bold="false" data-brp-justify="true" data-brp-hide-vn="false">

<!-- HEADER -->
<header class="brp-header">
 <div class="brp-header-logo">
  <span class="brp-header-ornament"></span>
  <h1>БІБЛІЯ</h1>
  <span class="brp-header-ornament right"></span>
 </div>
 <div class="brp-header-sub">На <a href="#">церковнослов'янській</a> · <a href="#">українській</a> · <a href="#">грецькій</a> · <a href="#">єврейській</a> · <a href="#">латинській</a> · <a href="#">англійській</a> мовах</div>
 <div class="brp-trans-bar">
  <div><label>Переклад</label><select id="brp-trans" class="brp-sel"><?php foreach($trans as $t):?><option value="<?=esc_attr($t->code)?>"<?php selected($t->code,'r')?>><?=esc_html($t->name)?></option><?php endforeach;?></select></div>
  <div><label>Паралельний</label><select id="brp-parallel" class="brp-sel"><option value="">— вимкнено —</option><?php foreach($trans as $t):?><option value="<?=esc_attr($t->code)?>"><?=esc_html($t->name)?></option><?php endforeach;?></select></div>
 </div>
</header>

<div class="brp-layout">

<!-- LEFT SIDEBAR -->
<nav id="brp-sidebar" class="brp-sidebar">
 <div class="brp-sb-inner">
  <div class="brp-sb-search"><input id="brp-sb-q" class="brp-input" placeholder="Пошук у Біблії…"><button id="brp-sb-go" class="brp-btn">🔍</button></div>
  <div class="brp-tabs">
   <button class="brp-tab-btn active" data-tab="nt" data-label-uk="Новий Завіт" data-label-ru="Новый Завет" data-label-en="New Testament">Новий Завіт</button>
   <button class="brp-tab-btn" data-tab="ot" data-label-uk="Старий Завіт" data-label-ru="Ветхий Завет" data-label-en="Old Testament">Старий Завіт</button>
   <?php if(is_user_logged_in()):?><button class="brp-tab-btn" data-tab="bm">★</button><?php endif;?>
  </div>
  <div id="brp-pane-nt" class="brp-tab-pane active">
   <?php
   $cats_nt_i18n=[
    'gospels'=>['uk'=>'Євангелія','ru'=>'Евангелия','en'=>'Gospels'],
    'acts'=>['uk'=>'Діяння Апостолів','ru'=>'Деяния Апостолов','en'=>'Acts'],
    'catholic'=>['uk'=>'Соборні Послання','ru'=>'Соборные Послания','en'=>'Catholic Epistles'],
    'paul'=>['uk'=>'Послання ап. Павла','ru'=>'Послания ап. Павла','en'=>'Pauline Epistles'],
    'prophecy_nt'=>['uk'=>'Одкровення','ru'=>'Откровение','en'=>'Revelation'],
   ];
   foreach($cats_nt as $ck=>$cn):
    $ci=$cats_nt_i18n[$ck]??['uk'=>$cn,'ru'=>$cn,'en'=>$cn];
   ?><div class="brp-cat"><div class="brp-cat-title" data-cat-uk="<?=esc_attr($ci['uk'])?>" data-cat-ru="<?=esc_attr($ci['ru'])?>" data-cat-en="<?=esc_attr($ci['en'])?>"><?=esc_html($ci['uk'])?></div>
   <?php foreach($nt as $b): if($b->category!==$ck)continue;?>
   <a href="#" class="brp-book-link" data-code="<?=esc_attr($b->code)?>" data-ch="<?=esc_attr($b->chapters_count)?>" data-name-ru="<?=esc_attr($b->name_ru)?>" data-name-uk="<?=esc_attr($b->name_uk)?>" data-name-en="<?=esc_attr($b->name_en)?>"><?=esc_html($b->name_uk?:$b->name_ru)?><?php if(!$b->is_canonical):?><span class="brp-nc-mark">†</span><?php endif;?></a>
   <?php endforeach;?></div><?php endforeach;?>
  </div>
  <div id="brp-pane-ot" class="brp-tab-pane">
   <p class="brp-ot-hint" data-hint-uk="Читання Біблії рекомендується починати з Нового Завіту." data-hint-ru="Чтение Библии рекомендуется начинать с Нового Завета." data-hint-en="It is recommended to start reading the Bible with the New Testament.">Читання Біблії рекомендується починати з Нового Завіту.</p>
   <?php
   $cats_ot_i18n=[
    'pentateuch'=>['uk'=>"П'ятикнижжя",'ru'=>'Пятикнижие Моисея','en'=>'Pentateuch'],
    'historical'=>['uk'=>'Історичні','ru'=>'Книги исторические','en'=>'Historical Books'],
    'historical_nc'=>['uk'=>'Історичні (некан.)','ru'=>'Исторические (некан.)','en'=>'Historical (non-canon.)'],
    'wisdom'=>['uk'=>'Повчальні','ru'=>'Книги учительные','en'=>'Wisdom Books'],
    'wisdom_nc'=>['uk'=>'Повчальні (некан.)','ru'=>'Учительные (некан.)','en'=>'Wisdom (non-canon.)'],
    'prophets'=>['uk'=>'Великі пророки','ru'=>'Великие пророки','en'=>'Major Prophets'],
    'prophets_minor'=>['uk'=>'Малі пророки','ru'=>'Малые пророки','en'=>'Minor Prophets'],
    'prophets_nc'=>['uk'=>'Пророчі (некан.)','ru'=>'Пророческие (некан.)','en'=>'Prophets (non-canon.)'],
   ];
   foreach($cats_ot as $ck=>$cn):
    $ci=$cats_ot_i18n[$ck]??['uk'=>$cn,'ru'=>$cn,'en'=>$cn];
   ?><div class="brp-cat"><div class="brp-cat-title" data-cat-uk="<?=esc_attr($ci['uk'])?>" data-cat-ru="<?=esc_attr($ci['ru'])?>" data-cat-en="<?=esc_attr($ci['en'])?>"><?=esc_html($ci['uk'])?></div>
   <?php foreach($ot as $b): if($b->category!==$ck)continue;?>
   <a href="#" class="brp-book-link" data-code="<?=esc_attr($b->code)?>" data-ch="<?=esc_attr($b->chapters_count)?>" data-name-ru="<?=esc_attr($b->name_ru)?>" data-name-uk="<?=esc_attr($b->name_uk)?>" data-name-en="<?=esc_attr($b->name_en)?>"><?=esc_html($b->name_uk?:$b->name_ru)?><?php if(!$b->is_canonical):?><span class="brp-nc-mark">†</span><?php endif;?></a>
   <?php endforeach;?></div><?php endforeach;?>
   <p class="brp-nc-hint" data-hint-uk="† Неканонічна книга" data-hint-ru="† Неканоническая книга" data-hint-en="† Non-canonical book">† Неканонічна книга</p>
  </div>
  <?php if(is_user_logged_in()):?>
  <div id="brp-pane-bm" class="brp-tab-pane"><div id="brp-bm-list" class="brp-bm-list"><p class="brp-empty">Завантаження…</p></div></div>
  <?php endif;?>
 </div>
</nav>

<!-- MAIN -->
<main class="brp-main">
 <div class="brp-chapter-bar">
  <div class="brp-chapter-bar-inner">
   <button id="brp-prev" class="brp-nav-arrow" title="Попередня глава (←)">◀</button>
   <div class="brp-cur-ref">
    <span id="brp-book-name">Від Матвія</span>
    <span class="brp-ch-sel-label">Глава <select id="brp-ch-sel" class="brp-sel" style="width:64px"></select></span>
   </div>
   <button id="brp-next" class="brp-nav-arrow" title="Наступна глава (→)">▶</button>
  </div>
  <div id="brp-ch-grid" class="brp-ch-grid"></div>
 </div>
 <div class="brp-text-area">
  <div class="brp-loading" id="brp-loader"><div class="brp-spinner"></div><span>Завантаження</span></div>
  <div id="brp-content" class="brp-verses"></div>
 </div>
</main>

<!-- RIGHT PANEL — ТЛУМАЧЕННЯ + AI -->
<aside class="brp-right-panel" id="brp-right">
 <div class="brp-rp-inner">
  <div class="brp-rp-section">
   <div class="brp-rp-title">Тлумачення</div>
   <div id="brp-comm-list">
    <div class="brp-empty">Натисніть на номер вірша для перегляду тлумачень</div>
   </div>
  </div>
  <div class="brp-rp-section">
   <div class="brp-rp-title">Ресурси</div>
   <div class="brp-info-links">
    <?php foreach(($resource_links??BibleReaderPro::default_resource_links()) as $rl): if(!empty($rl['url'])): ?>
    <a href="<?=esc_url($rl['url'])?>"><?=esc_html($rl['label'])?></a>
    <?php elseif(!empty($rl['label'])): ?>
    <span class="brp-res-nolink"><?=esc_html($rl['label'])?></span>
    <?php endif; endforeach; ?>
   </div>
  </div>
 </div>
</aside>
</div>

<!-- BOTTOM BAR -->
<div id="brp-bottom" class="brp-bottom hidden">
 <button class="brp-tool" id="brp-copy">📋 Копіювати</button>
 <button class="brp-tool" id="brp-bm-btn">★ Закладка</button>
 <button class="brp-tool" id="brp-err-btn">⚠ Помилка</button>
 <button class="brp-tool" id="brp-set-btn">⚙ Налаштування</button>
</div>
<button id="brp-mob-btn" class="brp-mob-toggle" aria-label="Відкрити навігацію">☰</button>

<!-- SETTINGS MODAL -->
<div id="brp-set-modal" class="brp-modal"><div class="brp-modal-box"><div class="brp-modal-head"><h3>Налаштування</h3><button class="brp-modal-x">✕</button></div><div class="brp-modal-body">

 <div class="brp-set-sec">
  <h4>Тема оформлення</h4>
  <div class="brp-theme-btns">
   <button class="brp-theme-btn" data-t="default">🌿 Стандартна</button>
   <button class="brp-theme-btn" data-t="dark">🌙 Темна</button>
   <button class="brp-theme-btn" data-t="sepia">📜 Сепія</button>
  </div>
  <p style="font-size:11px;color:var(--text-3);margin-top:8px">«Стандартна» успадковує кольори теми вашого сайту</p>
 </div>

 <div class="brp-set-sec">
  <h4>Розмір тексту</h4>
  <div class="brp-fs-btns">
   <button class="brp-fs-btn" data-fs="sm" style="font-size:13px">Мал</button>
   <button class="brp-fs-btn on" data-fs="md" style="font-size:15px">Сер</button>
   <button class="brp-fs-btn" data-fs="lg" style="font-size:18px">Вел</button>
   <button class="brp-fs-btn" data-fs="xl" style="font-size:22px">Дуже</button>
  </div>
 </div>

 <div class="brp-set-sec">
  <h4>Шрифт</h4>
  <select id="brp-s-font" class="brp-sel" style="width:100%;max-width:100%">
   <option value="'Lora','Palatino Linotype',Georgia,serif">Lora (засічки)</option>
   <option value="'PT Serif',Georgia,serif">PT Serif</option>
   <option value="Georgia,serif">Georgia</option>
   <option value="'Montserrat',sans-serif">Montserrat (без засічок)</option>
  </select>
 </div>

 <div class="brp-set-sec">
  <h4>Слова Христа</h4>
  <div class="brp-radio-group">
   <label><input type="radio" name="brp_cw" value="none"> Без виділення</label>
   <label><input type="radio" name="brp_cw" value="red" checked> 🔴 Червоний</label>
   <label><input type="radio" name="brp_cw" value="green"> 🟢 Зелений</label>
   <label><input type="radio" name="brp_cw" value="blue"> 🔵 Синій</label>
  </div>
 </div>

 <div class="brp-set-sec">
  <h4>Ширина колонки</h4>
  <div class="brp-width-btns">
   <button class="brp-width-btn" data-w="narrow">Вузька</button>
   <button class="brp-width-btn on" data-w="medium">Середня</button>
   <button class="brp-width-btn" data-w="wide">Широка</button>
   <button class="brp-width-btn" data-w="adaptive">Повна</button>
  </div>
 </div>

 <div class="brp-set-sec">
  <h4>Відображення</h4>
  <label class="brp-check-label"><input type="checkbox" id="brp-s-bold"> Жирний текст</label>
  <label class="brp-check-label"><input type="checkbox" id="brp-s-justify" checked> По ширині</label>
  <label class="brp-check-label"><input type="checkbox" id="brp-s-hyphens"> Переноси</label>
  <label class="brp-check-label"><input type="checkbox" id="brp-s-hide-vn"> Сховати номери</label>
  <label class="brp-check-label"><input type="checkbox" id="brp-s-color-cols"> Кольорові колонки</label>
 </div>

 <div class="brp-set-sec">
  <h4>Копіювання</h4>
  <label class="brp-check-label"><input type="checkbox" id="brp-s-copy-vn" checked> Додавати номер вірша</label>
  <label class="brp-check-label"><input type="checkbox" id="brp-s-copy-br"> Кожен вірш з нового рядка</label>
  <label class="brp-check-label"><input type="checkbox" id="brp-s-copy-q"> Обрамляти в лапки «»</label>
 </div>

 <button class="brp-btn" id="brp-s-reset" style="width:100%;justify-content:center;margin-top:8px">↺ Скинути налаштування</button>
</div></div></div>

<!-- SEARCH MODAL -->
<div id="brp-search-modal" class="brp-modal"><div class="brp-modal-box wide"><div class="brp-modal-head"><h3>Пошук у Біблії</h3><button class="brp-modal-x">✕</button></div><div class="brp-modal-body">
 <div class="brp-search-bar">
  <input id="brp-search-q" class="brp-input" placeholder="Введіть текст для пошуку…" autofocus>
  <select id="brp-search-bf" class="brp-sel">
   <option value="">Уся Біблія</option>
   <optgroup label="Новий Завіт"><?php foreach($nt as $b):?><option value="<?=esc_attr($b->code)?>"><?=esc_html($b->name_uk?:$b->name_ru)?></option><?php endforeach;?></optgroup>
   <optgroup label="Старий Завіт"><?php foreach($ot as $b):?><option value="<?=esc_attr($b->code)?>"><?=esc_html($b->name_uk?:$b->name_ru)?></option><?php endforeach;?></optgroup>
  </select>
  <button id="brp-search-go" class="brp-btn brp-btn-primary">Знайти</button>
 </div>
 <div id="brp-search-res" class="brp-search-results"></div>
</div></div></div>

<!-- BOOKMARK MODAL -->
<div id="brp-bm-modal" class="brp-modal"><div class="brp-modal-box"><div class="brp-modal-head"><h3>Додати закладку</h3><button class="brp-modal-x">✕</button></div><div class="brp-modal-body">
 <p id="brp-bm-ref" style="font-family:var(--font-serif);font-size:18px;color:var(--gold);margin-bottom:14px"></p>
 <div style="margin-bottom:12px">
  <label style="font-family:var(--font-ui);font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:var(--text-3);display:block;margin-bottom:8px">Колір закладки</label>
  <div class="brp-colors">
   <span class="brp-color-dot on" data-c="#C9A96E" style="background:#C9A96E"></span>
   <span class="brp-color-dot" data-c="#4CAF50" style="background:#4CAF50"></span>
   <span class="brp-color-dot" data-c="#5B9BD5" style="background:#5B9BD5"></span>
   <span class="brp-color-dot" data-c="#E07B72" style="background:#E07B72"></span>
   <span class="brp-color-dot" data-c="#9B7BC4" style="background:#9B7BC4"></span>
  </div>
 </div>
 <textarea id="brp-bm-note" class="brp-input" rows="3" style="resize:vertical" placeholder="Ваша нотатка…"></textarea>
 <button id="brp-bm-save" class="brp-btn brp-btn-primary" style="width:100%;justify-content:center;margin-top:14px">★ Зберегти закладку</button>
</div></div></div>

<!-- ERROR MODAL -->
<div id="brp-err-modal" class="brp-modal"><div class="brp-modal-box"><div class="brp-modal-head"><h3>Повідомити про помилку</h3><button class="brp-modal-x">✕</button></div><div class="brp-modal-body">
 <p style="font-size:13px;color:var(--text-2);margin-bottom:12px">Виділіть текст з помилкою перед натисканням кнопки.</p>
 <div style="background:var(--bg-overlay);border:1px solid var(--border);border-radius:var(--radius);padding:10px 12px;margin-bottom:12px">
  <span style="font-family:var(--font-ui);font-size:10px;color:var(--text-3);text-transform:uppercase;letter-spacing:1px;display:block;margin-bottom:4px">Виділено:</span>
  <span id="brp-err-sel" style="color:var(--text-2);font-family:var(--font-serif)">(нічого не виділено)</span>
 </div>
 <textarea id="brp-err-desc" class="brp-input" rows="3" style="resize:vertical" placeholder="Опишіть помилку…"></textarea>
 <button id="brp-err-send" class="brp-btn brp-btn-primary" style="width:100%;justify-content:center;margin-top:14px">📨 Надіслати</button>
</div></div></div>

<div id="brp-toast" class="brp-toast"></div>
</div>
