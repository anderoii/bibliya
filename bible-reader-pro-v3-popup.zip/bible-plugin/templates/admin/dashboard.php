<?php if(!defined('ABSPATH'))exit; global $wpdb;
$books_count=$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}brp_books");
$trans_count=$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}brp_translations");
$verses_count=$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}brp_verses");
$comm_count=$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}brp_commentaries");
$bm_count=$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}brp_bookmarks");
$err_count=$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}brp_errors WHERE status='new'");
?>
<div class="wrap">
<h1>Bible Reader Pro — Панель керування</h1>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:16px;margin-top:20px">
 <div style="background:#fff;padding:20px;border:1px solid #ddd;border-radius:8px;text-align:center">
  <div style="font-size:36px;font-weight:700;color:#1a5276"><?=$books_count?></div>
  <div style="color:#666">Книг Біблії</div>
 </div>
 <div style="background:#fff;padding:20px;border:1px solid #ddd;border-radius:8px;text-align:center">
  <div style="font-size:36px;font-weight:700;color:#1a5276"><?=$trans_count?></div>
  <div style="color:#666">Перекладів</div>
 </div>
 <div style="background:#fff;padding:20px;border:1px solid #ddd;border-radius:8px;text-align:center">
  <div style="font-size:36px;font-weight:700;color:#1a5276"><?=number_format($verses_count)?></div>
  <div style="color:#666">Віршів</div>
 </div>
 <div style="background:#fff;padding:20px;border:1px solid #ddd;border-radius:8px;text-align:center">
  <div style="font-size:36px;font-weight:700;color:#c8a415"><?=number_format($comm_count)?></div>
  <div style="color:#666">Толкувань</div>
 </div>
 <div style="background:#fff;padding:20px;border:1px solid #ddd;border-radius:8px;text-align:center">
  <div style="font-size:36px;font-weight:700;color:#2e7d32"><?=$bm_count?></div>
  <div style="color:#666">Закладок</div>
 </div>
 <div style="background:#fff;padding:20px;border:1px solid #ddd;border-radius:8px;text-align:center">
  <div style="font-size:36px;font-weight:700;color:#e53935"><?=$err_count?></div>
  <div style="color:#666">Нових помилок</div>
 </div>
</div>
<div style="margin-top:24px;background:#fff;padding:20px;border:1px solid #ddd;border-radius:8px">
 <h2>Швидкий старт</h2>
 <ol style="line-height:2">
  <li>Перейдіть в <strong>Імпорт текстів</strong> щоб завантажити тексти Біблії</li>
  <li>Формат: кожен рядок = <code>номер_вірша текст</code></li>
  <li>Сторінка <code>/bible/</code> вже створена автоматично</li>
  <li>Використовуйте шорткод <code>[bible_reader]</code> на будь-якій сторінці</li>
  <li>URL формат: <code>/bible/#Mt.1&r</code> (книга.глава&переклад)</li>
  <li>Паралельний переклад через тильду: <code>/bible/#Ex.1&r~utfcs</code></li>
 </ol>
</div>
</div>
