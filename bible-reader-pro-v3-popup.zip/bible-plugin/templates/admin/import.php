<?php if(!defined('ABSPATH'))exit; global $wpdb;
$books=$wpdb->get_results("SELECT code,name_uk,name_ru FROM {$wpdb->prefix}brp_books ORDER BY sort_order");
$trans=$wpdb->get_results("SELECT code,name FROM {$wpdb->prefix}brp_translations ORDER BY sort_order");
$nonce=wp_create_nonce('brp');
?>
<div class="wrap">
<h1>Імпорт текстів Біблії</h1>

<!-- ══ TAB NAV ══ -->
<nav class="nav-tab-wrapper" style="margin-bottom:0">
 <a href="#" class="nav-tab nav-tab-active" id="tab-manual-btn">✍ Ручний ввід</a>
 <a href="#" class="nav-tab" id="tab-albible-btn">📂 Імпорт з alBible Lite (JSON)</a>
</nav>

<!-- ══ TAB 1: Manual import ══ -->
<div id="tab-manual" style="background:#fff;padding:20px;border:1px solid #ddd;border-top:none;border-radius:0 0 8px 8px;max-width:700px">
 <p>Формат тексту: кожен рядок — <code>номер текст_вірша</code>. Наприклад:</p>
 <pre style="background:#f5f5f5;padding:10px;border-radius:4px;font-size:13px">1 На початку створив Бог небо і землю.
2 Земля ж була пуста та порожня, і темрява була над безоднею.
3 І сказав Бог: Нехай буде світло. І стало світло.</pre>
 <table class="form-table">
  <tr><th>Книга:</th><td><select id="brp-imp-book" class="regular-text"><?php foreach($books as $b):?><option value="<?=esc_attr($b->code)?>"><?=esc_html($b->name_uk?:$b->name_ru)?> (<?=$b->code?>)</option><?php endforeach;?></select></td></tr>
  <tr><th>Глава:</th><td><input type="number" id="brp-imp-ch" class="small-text" min="1" value="1"></td></tr>
  <tr><th>Переклад:</th><td><select id="brp-imp-trans" class="regular-text"><?php foreach($trans as $t):?><option value="<?=esc_attr($t->code)?>"><?=esc_html($t->name)?></option><?php endforeach;?></select></td></tr>
  <tr><th>Текст:</th><td><textarea id="brp-imp-text" class="large-text" rows="15" placeholder="1 Текст першого вірша&#10;2 Текст другого вірша"></textarea></td></tr>
 </table>
 <button id="brp-imp-btn" class="button button-primary button-large">Імпортувати</button>
 <span id="brp-imp-status" style="margin-left:12px"></span>
</div>

<!-- ══ TAB 2: alBible Lite JSON import ══ -->
<div id="tab-albible" style="display:none;background:#fff;padding:20px;border:1px solid #ddd;border-top:none;border-radius:0 0 8px 8px;max-width:700px">
 <div style="background:#e8f4fd;border-left:4px solid #2196F3;padding:12px 16px;margin-bottom:16px;border-radius:0 4px 4px 0">
  <strong>📂 alBible Lite — формат JSON</strong><br>
  <span style="font-size:13px">Вкажіть абсолютний шлях до JSON-файлу книги з папки <code>alBible Lite</code> (<code>uk/</code> або <code>ru/</code>).
  Файл повинен знаходитись всередині <code>wp-content/</code>.<br>
  Приклад шляху: <code>/var/www/html/wp-content/plugins/albible-lite/uk/juda</code></span>
 </div>

 <div style="background:#fff3e0;border-left:4px solid #FF9800;padding:10px 16px;margin-bottom:16px;border-radius:0 4px 4px 0;font-size:13px">
  <strong>📌 Відповідність кодів книг:</strong><br>
  alBible Lite використовує коди типу <code>juda</code> (файл), а Bible Reader Pro — <code>Juda</code> (DB code).<br>
  Перевірте відповідність нижче і виберіть правильну книгу перед імпортом.
 </div>

 <table class="form-table">
  <tr>
   <th>Шлях до JSON-файлу alBible Lite:</th>
   <td>
    <input type="text" id="brp-alb-path" class="large-text" placeholder="/var/www/html/wp-content/plugins/albible-lite/uk/juda" style="width:100%">
    <button type="button" id="brp-alb-detect" class="button" style="margin-top:6px">🔍 Автовизначити wp-content шлях</button>
    <p class="description">Файл повинен бути JSON-масивом об'єктів з полями: <code>part</code> (розділ), <code>stix</code> (вірш), <code>text</code> (текст)</p>
   </td>
  </tr>
  <tr>
   <th>Книга Bible Reader Pro (DB code):</th>
   <td>
    <select id="brp-alb-book" class="regular-text">
     <?php foreach($books as $b):?>
     <option value="<?=esc_attr($b->code)?>"><?=esc_html($b->name_uk?:$b->name_ru)?> (<?=$b->code?>)</option>
     <?php endforeach;?>
    </select>
   </td>
  </tr>
  <tr>
   <th>Переклад (код):</th>
   <td>
    <select id="brp-alb-trans" class="regular-text">
     <?php foreach($trans as $t):?>
     <option value="<?=esc_attr($t->code)?>"><?=esc_html($t->name)?></option>
     <?php endforeach;?>
    </select>
    <p class="description">Для українського Огієнка виберіть <strong>k (Українська Огієнко)</strong></p>
   </td>
  </tr>
 </table>

 <button id="brp-alb-btn" class="button button-primary button-large">📥 Імпортувати з alBible Lite</button>
 <span id="brp-alb-status" style="margin-left:12px;font-size:13px"></span>

 <!-- Quick reference table -->
 <h3 style="margin-top:24px">Таблиця відповідності: alBible Lite → Bible Reader Pro</h3>
 <p style="font-size:12px;color:#666">Назви файлів у папці alBible Lite → коди книг у Bible Reader Pro</p>
 <table class="widefat striped" style="max-width:600px;font-size:12px">
  <thead><tr><th>Файл alBible Lite</th><th>Код Bible Reader Pro</th><th>Назва</th></tr></thead>
  <tbody>
  <?php
  $mapping=[
   'gen'=>'Gen','ex'=>'Ex','lev'=>'Lev','num'=>'Num','deu'=>'Deut',
   'nav'=>'Nav','sud'=>'Judg','ruf'=>'Rth','king1'=>'1Sam','king2'=>'2Sam',
   'king3'=>'1King','king4'=>'2King','para1'=>'1Chron','para2'=>'2Chron',
   'ezr1'=>'Ezr','nee'=>'Nehem','esf'=>'Est','iov'=>'Job','ps'=>'Ps',
   'prov'=>'Prov','eccl'=>'Eccl','song'=>'Song','isa'=>'Is','jer'=>'Jer',
   'lam'=>'Lam','eze'=>'Ezek','dan'=>'Dan','hos'=>'Hos','joe'=>'Joel',
   'am'=>'Am','avd'=>'Avd','jona'=>'Jona','mih'=>'Mic','nau'=>'Naum',
   'avv'=>'Habak','sof'=>'Sofon','agg'=>'Hag','zah'=>'Zah','mal'=>'Mal',
   'tov'=>'Tov','varuh'=>'Bar','posjer'=>'pJer','sir'=>'Sir','prem'=>'Solom',
   'jdi'=>'Judf','mak1'=>'1Mac','mak2'=>'2Mac',
   // NT (uk only)
   'mf'=>'Mt','mk'=>'Mk','lk'=>'Lk','jn'=>'Jn','act'=>'Act',
   'rom'=>'Rom','co1'=>'1Cor','co2'=>'2Cor','gal'=>'Gal','eph'=>'Eph',
   'flp'=>'Phil','col'=>'Col','fe1'=>'1Thes','fe2'=>'2Thes',
   'ti1'=>'1Tim','ti2'=>'2Tim','tit'=>'Tit','flm'=>'Phlm','heb'=>'Heb',
   'jak'=>'Jac','pe1'=>'1Pet','pe2'=>'2Pet','jn1'=>'1Jn','jn2'=>'2Jn',
   'jn3'=>'3Jn','jud'=>'Juda','rev'=>'Apok',
  ];
  foreach($mapping as $alb=>$brp):
   $bname='';
   foreach($books as $b){ if($b->code===$brp){$bname=$b->name_uk?:$b->name_ru;break;} }
  ?>
  <tr>
   <td><code><?=esc_html($alb)?></code></td>
   <td><code><?=esc_html($brp)?></code></td>
   <td><?=esc_html($bname)?></td>
  </tr>
  <?php endforeach;?>
  </tbody>
 </table>
</div>

</div><!-- .wrap -->

<script>
jQuery(function($){
 // ── Tab switching ──
 $('#tab-manual-btn,#tab-albible-btn').on('click',function(e){
  e.preventDefault();
  $('.nav-tab').removeClass('nav-tab-active');
  $(this).addClass('nav-tab-active');
  var t=$(this).attr('id').replace('-btn','');
  $('#tab-manual,#tab-albible').hide();
  $('#'+t).show();
 });

 // ── Manual import ──
 $('#brp-imp-btn').on('click',function(){
  var btn=$(this).prop('disabled',true),$s=$('#brp-imp-status').text('Імпорт...');
  $.post(ajaxurl,{action:'brp_import_text',nonce:'<?=$nonce?>',
   book:$('#brp-imp-book').val(),chapter:$('#brp-imp-ch').val(),
   trans:$('#brp-imp-trans').val(),text:$('#brp-imp-text').val()
  },function(r){
   btn.prop('disabled',false);
   $s.text(r.success?'✅ Імпортовано '+r.data.count+' віршів':'❌ Помилка: '+(r.data?r.data.msg:'unknown'));
  }).fail(function(){btn.prop('disabled',false);$s.text("❌ Помилка з'єднання");});
 });

 // ── Auto-detect wp-content path ──
 $('#brp-alb-detect').on('click',function(){
  var wpContent='<?=esc_js(WP_CONTENT_DIR)?>/plugins/albible-lite/uk/';
  $('#brp-alb-path').val(wpContent+'gen');
  alert('Шлях встановлено. Замініть "gen" на потрібний файл книги.');
 });

 // ── alBible Lite import ──
 $('#brp-alb-btn').on('click',function(){
  var path=$.trim($('#brp-alb-path').val());
  var book=$('#brp-alb-book').val();
  var trans=$('#brp-alb-trans').val();
  if(!path){alert('Вкажіть шлях до файлу');return;}
  var btn=$(this).prop('disabled',true);
  var $s=$('#brp-alb-status').html('<em>⏳ Читання файлу та імпорт...</em>');
  $.post(ajaxurl,{action:'brp_import_albible',nonce:'<?=$nonce?>',
   book:book,trans:trans,path:path
  },function(r){
   btn.prop('disabled',false);
   if(r.success){
    $s.html('✅ <strong>Імпортовано '+r.data.count+' віршів</strong> для книги <code>'+r.data.book+'</code> (переклад: <code>'+r.data.trans+'</code>)');
   } else {
    $s.html('❌ Помилка: '+(r.data?r.data.msg:'невідома'));
   }
  }).fail(function(){btn.prop('disabled',false);$s.html("❌ Помилка з'єднання");});
 });
});
</script>
